/***************************************************************************//**
* \file BLE_HAL_Uart.c
* \version 2.0
*
*  This file provides the source code to the API for the UART Component.
*
********************************************************************************
* \copyright
* Copyright 2016-2017, Cypress Semiconductor Corporation. All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#include "BLE_HAL_Uart.h"
#include "sysint/cy_sysint.h"
#include "cyfitter_sysint.h"
#include "cyfitter_sysint_cfg.h"

#if defined(__cplusplus)
extern "C" {
#endif

/***************************************
*     Global variables
***************************************/

/** BLE_HAL_Uart_initVar indicates whether the BLE_HAL_Uart
*  component has been initialized. The variable is initialized to 0
*  and set to 1 the first time BLE_HAL_Uart_Start() is called.
*  This allows  the component to restart without reinitialization
*  after the first call to the BLE_HAL_Uart_Start() routine.
*
*  If re-initialization of the component is required, then the
*  BLE_HAL_Uart_Init() function can be called before the
*  BLE_HAL_Uart_Start() or BLE_HAL_Uart_Enable() function.
*/
uint8_t BLE_HAL_Uart_initVar = 0U;


/** The instance-specific configuration structure.
* The pointer to this structure should be passed to Cy_SCB_UART_Init function
* to initialize component with GUI selected settings.
*/
cy_stc_scb_uart_config_t const BLE_HAL_Uart_config =
{
    .uartMode                   = CY_SCB_UART_STANDARD,
    .enableMutliProcessorMode   = false,
    .smartCardRetryOnNack       = false,
    .irdaInvertRx               = false,
    .irdaEnableLowPowerReceiver = false,

    .oversample                 = 13UL,
    
    .enableMsbFirst             = false,
    .dataWidth                  = 8UL,
    .parity                     = CY_SCB_UART_PARITY_NONE,
    .stopBits                   = CY_SCB_UART_STOP_BITS_1,
    .enableInputFilter          = false,
    .breakWidth                 = 11UL,
    .dropOnFrameError           = false,
    .dropOnParityError          = false,

    .receiverAddress            = 0x0UL,
    .receiverAddressMask        = 0x0UL,
    .acceptAddrInFifo           = false,

    .enableCts                  = true,
    .ctsPolarity                = CY_SCB_UART_ACTIVE_LOW,
    .rtsRxFifoLevel             = 4UL,
    .rtsPolarity                = CY_SCB_UART_ACTIVE_LOW,

    .rxFifoTriggerLevel         = 0UL,
    .rxFifoIntEnableMask        = 0x64UL,

    .txFifoTriggerLevel         = 0UL,
    .txFifoIntEnableMask        = 0x220UL
};

/** The instance-specific context structure.
* It is used while the driver operation for internal configuration and
* data keeping for the UART. The user should not modify anything in this 
* structure.
*/
cy_stc_scb_uart_context_t BLE_HAL_Uart_context;


/*******************************************************************************
* Function Name: BLE_HAL_Uart_Start
****************************************************************************//**
*
* Invokes BLE_HAL_Uart_Init() and BLE_HAL_Uart_Enable().
* Also configures interrupt if it is internal.
* After this function call the component is enabled and ready for operation.
* This is the preferred method to begin component operation.
*
* \globalvars
* \ref BLE_HAL_Uart_initVar - used to check initial configuration,
* modified  on first function call.
*
*******************************************************************************/
void BLE_HAL_Uart_Start(void)
{
    if (0U == BLE_HAL_Uart_initVar)
    {
        /* Configure component */
        (void) Cy_SCB_UART_Init(BLE_HAL_Uart_HW, &BLE_HAL_Uart_config, &BLE_HAL_Uart_context);

        /* Hook interrupt service routine */
    #if defined(BLE_HAL_Uart_SCB_IRQ__INTC_ASSIGNED)
        (void) Cy_SysInt_Init(&BLE_HAL_Uart_SCB_IRQ_cfg, &BLE_HAL_Uart_Interrupt);
    #endif /* (BLE_HAL_Uart_SCB_IRQ__INTC_ASSIGNED) */
    
        /* Component is configured */
        BLE_HAL_Uart_initVar = 1U;
    }

    /* Enable interrupt in NVIC */
#if defined(BLE_HAL_Uart_SCB_IRQ__INTC_ASSIGNED)
    NVIC_EnableIRQ((IRQn_Type) BLE_HAL_Uart_SCB_IRQ_cfg.intrSrc);
#endif /* (BLE_HAL_Uart_SCB_IRQ__INTC_ASSIGNED) */

    Cy_SCB_UART_Enable(BLE_HAL_Uart_HW);
}

#if defined(__cplusplus)
}
#endif


/* [] END OF FILE */
