


#include "project.h"
#include "stdio.h"
#include "math.h"

static uint8 data[1] = {0}; 
volatile float val;
volatile float volts;
volatile float moisture;
char outputStr[32]; // For UART output
int readADCFlag = 0; // Flag to indicate ADC reading

void genericEventHandler(uint32_t event, void *eventParameter) {
    switch (event) {
        case CY_BLE_EVT_STACK_ON:
        case CY_BLE_EVT_GAP_DEVICE_DISCONNECTED:
            Cy_BLE_GAPP_StartAdvertisement(CY_BLE_ADVERTISING_FAST, CY_BLE_PERIPHERAL_CONFIGURATION_0_INDEX);
            break;
        
        case CY_BLE_EVT_GATT_CONNECT_IND:
            // Connection established
            break;
        
        case CY_BLE_EVT_GATTS_WRITE_CMD_REQ:
            {
                cy_stc_ble_gatts_write_cmd_req_param_t *writeReqParameter = (cy_stc_ble_gatts_write_cmd_req_param_t *)eventParameter;
                if (CY_BLE_DEVICE_INTERFACE_DEVICE_INBOUND_CHAR_HANDLE == writeReqParameter->handleValPair.attrHandle) {
                    data[0] = writeReqParameter->handleValPair.value.val[0];
                    Cy_BLE_GATTS_WriteRsp(writeReqParameter->connHandle);
                }
            }
            break;
    }
}

void bleInterruptNotify() {
    Cy_BLE_ProcessEvents();
}

void readADCValue() {
    val = Cy_SAR_GetResult16(SAR,0); // Get the ADC result
    volts = Cy_SAR_CountsTo_Volts(SAR,0,val); // Convert to voltage
 //   volts = 1.2; //tester
        volts = volts - 0.43; //ms accpunting
        printf(" %f volts ", volts);
    //snprintf(outputStr, sizeof(outputStr), "%.2f", volts); // Convert voltage to string for UART
       //Cy_GPIO_Write(moisture_VCC_PORT, moisture_VCC_NUM, 1); 
    moisture = Cy_SAR_GetResult16(SAR, 1);
    printf(" %f ms unit ", moisture); 
}

void updateBLECharacteristic() {
    cy_stc_ble_gatt_handle_value_pair_t serviceHandle;
    cy_stc_ble_gatt_value_t serviceData;
    
    // Convert volts to an integer value * 100
    int voltsInt = (int)(volts * 100);// if doesnt work then this line is wrong
  //  int voltsInt = 123; //tester
    uint8_t voltsData[2];
    
    voltsData[0] = voltsInt; 
    
    serviceData.val = voltsData;
    serviceData.len = 1; // Data length is 2 bytes
    
    serviceHandle.attrHandle = CY_BLE_DEVICE_INTERFACE_DEVICE_OUTBOUND_CHAR_HANDLE;
    serviceHandle.value = serviceData;
    
    Cy_BLE_GATTS_WriteAttributeValueLocal(&serviceHandle); // Update GATT database
}

int main(void) {
    __enable_irq();
    Cy_SysEnableCM4(CY_CORTEX_M4_APPL_ADDR); 
    ADC_Start(); 
        UART_Start();
        //setvbuf(stdin, NULL,_IONBF,0);
    Cy_SAR_StartConvert(SAR, CY_SAR_START_CONVERT_CONTINUOUS);

    Cy_BLE_Start(genericEventHandler);
    
    while (Cy_BLE_GetState() != CY_BLE_STATE_ON) {
        Cy_BLE_ProcessEvents();
    }
    Cy_BLE_RegisterAppHostCallback(bleInterruptNotify);
    
    for (;;) {
        Cy_BLE_ProcessEvents(); // Handle BLE events

        if (readADCFlag) { // If it's time to read ADC
            readADCValue();
            updateBLECharacteristic(); // Update BLE characteristic with new ADC value
            printf("%s\n", outputStr); // Output the voltage to UART
            readADCFlag = 0; // Reset flag
        }

        CyDelay(1000); // Periodic delay, adjust as needed for your application
        readADCFlag = 1; // Set flag to read ADC on next loop iteration
    }
}
